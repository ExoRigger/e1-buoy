
/**********************************************************************************************************************/
 /*\title Shell via UART communication
 * \abstract A Shell is used to parse a command line and call the corresponding command execution. The ASCLIN module is used to interface with the Shell through the USB port via UART.
 * \description The ASCLIN module is configured for UART communication.
 *              The Shell from iLLDs exploits the ASCLIN module to interpret and manage commands from the
 *              user like "info", "toggle [x]" or "help".
 *
 * \name ASCLIN_Shell_UART_1_KIT_TC375_SB
 * \version V1.0.1
 * \board hitex ShieldBuddy, KIT_A2G_TC375_ARD_SB, TC37xTP_A-Step
 * \keywords ASC, ASCLIN_Shell_UART_1, AURIX, UART, VCOM, serial communication, shell
 * \documents https://www.infineon.com/aurix-expert-training/Infineon-AURIX_ASCLIN_Shell_UART_1_KIT_TC375_SB-TR-v01_00_01-EN.pdf
 * \documents https://www.infineon.com/aurix-expert-training/TC37A_iLLD_UM_1_0_1_12_1.chm
 * \lastUpdated 2021-03-22
 *********************************************************************************************************************/
#include "Ifx_Types.h"
#include "IfxCpu.h"
#include "IfxScuWdt.h"
#include "ASCLIN_Shell_UART.h"

IFX_ALIGN(4) IfxCpu_syncEvent g_cpuSyncEvent = 0;

void core0_main(void)
{
    IfxCpu_enableInterrupts();
    
    /* !!WATCHDOG0 AND SAFETY WATCHDOG ARE DISABLED HERE!!
     * Enable the watchdogs and service them periodically if it is required
     */
    IfxScuWdt_disableCpuWatchdog(IfxScuWdt_getCpuWatchdogPassword());
    IfxScuWdt_disableSafetyWatchdog(IfxScuWdt_getSafetyWatchdogPassword());
    
    /* Wait for CPU sync event */
    IfxCpu_emitEvent(&g_cpuSyncEvent);
    IfxCpu_waitEvent(&g_cpuSyncEvent, 1);
    
    /* Initialize the Shell Interface and the UART communication */
    initShellInterface();
    initBackupShell();

    while(1)
    {
        runShellInterface(); /* Run the application shell */
        runBackupShell();
    }
}
