/*********************************************************************************************************************/
/*-----------------------------------------------------Includes------------------------------------------------------*/
/*********************************************************************************************************************/
#include "IfxPort.h"
#include "Ifx_Types.h"

/*********************************************************************************************************************/
/*------------------------------------------------------Macros-------------------------------------------------------*/
/*********************************************************************************************************************/
#define PIN_V_BAT &MODULE_P32,4

#define PIN_IN1 &MODULE_P2,7
#define LED_IN1 &MODULE_P10,4

#define PIN_IN2 &MODULE_P10,5
#define LED_IN2 &MODULE_P2,3

#define PIN_IN3 &MODULE_P10,3
#define LED_IN3 &MODULE_P10,1

#define PIN_IN4 &MODULE_P2,1
#define LED_IN4 &MODULE_P10,2

#define PIN_DEN_1_3 &MODULE_P2,4
#define PIN_DEN_2_4 &MODULE_P2,6

#define PIN_IS_1_2 &MODULE_P23,1
#define PIN_IS_3_4 &MODULE_P33,9

#define PIN_OL_OFF &MODULE_P2,5

/*********************************************************************************************************************/
/*-------------------------------------------------Global variables--------------------------------------------------*/
/*********************************************************************************************************************/


/*********************************************************************************************************************/
/*--------------------------------------------Private Variables/Constants--------------------------------------------*/
/*********************************************************************************************************************/

/*********************************************************************************************************************/
/*------------------------------------------------Function Prototypes------------------------------------------------*/
/*********************************************************************************************************************/

void initPMM(void);
void runPMM(void);
void infoChannels(void);
void readChannels(void);
void setChannels(void);
void cycleChannels(void);



/*********************************************************************************************************************/
/*---------------------------------------------Function Implementations----------------------------------------------*/
/*********************************************************************************************************************/

void initPMM(void) {
    ;
    /* Initialize GPIO pins for the PMM
     * There are 4 Digital pins for

    IfxPort_setPinMode(PIN_IN1, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(LED_IN1, IfxPort_Mode_outputPushPullGeneral);

    IfxPort_setPinMode(PIN_IN2, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(LED_IN2, IfxPort_Mode_outputPushPullGeneral);

    IfxPort_setPinMode(PIN_IN3, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(LED_IN3, IfxPort_Mode_outputPushPullGeneral);

    IfxPort_setPinMode(PIN_IN4, IfxPort_Mode_outputPushPullGeneral);
    IfxPort_setPinMode(LED_IN4, IfxPort_Mode_outputPushPullGeneral);

*/


}

